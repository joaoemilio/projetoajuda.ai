This sample display the use of wait operation in bpel processes.
In the sample if the user input is not equal to 10 a response will be provided after 15 seconds.