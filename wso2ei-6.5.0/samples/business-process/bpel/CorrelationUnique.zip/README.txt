This sample demonstrates the use of multiple correlation sets within one bpel process.
Three operations are executed parallel where only one correlation set is made to be initiate= true. Therefore within each process only one correlation set will be creating new instances.
Some test request response values expected are also available in the sample.
